package server

import (
    "encoding/json"
    "io"
    "net/http"
    "github.com/Beryllium/cross-command-app/commander"
)

type CommandRequest struct {
    Type    string `json:"type"`
    Payload string `json:"payload"`
}

type CommandResponse struct {
    Success bool        `json:"success"`
    Data    interface{} `json:"data,omitempty"`
    Error   string      `json:"error,omitempty"`
}

func HandleRequests(cmdr commander.Commander) http.Handler {
    mux := http.NewServeMux()
    mux.HandleFunc("/execute", handleCommand(cmdr))
    return mux
}

func handleCommand(cmdr commander.Commander) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodPost {
            http.Error(w, "Only POST allowed", http.StatusMethodNotAllowed)
            return
        }

        body, _ := io.ReadAll(r.Body)
        var req CommandRequest
        json.Unmarshal(body, &req)

        switch req.Type {
        case "ping":
            result, err := cmdr.Ping(req.Payload)
            if err != nil {
                respond(w, CommandResponse{Success: false, Error: err.Error()})
                return
            }
            respond(w, CommandResponse{Success: true, Data: result})
        case "sysinfo":
            result, err := cmdr.GetSystemInfo()
            if err != nil {
                respond(w, CommandResponse{Success: false, Error: err.Error()})
                return
            }
            respond(w, CommandResponse{Success: true, Data: result})
        default:
            respond(w, CommandResponse{Success: false, Error: "Unknown command"})
        }
    }
}

func respond(w http.ResponseWriter, res CommandResponse) {
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(res)
}
