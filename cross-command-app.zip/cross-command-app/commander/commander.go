package commander

import (
    "errors"
    "net"
    "os"
    "os/exec"
    "strings"
    "time"
    "fmt"
)

type Commander interface {
    Ping(host string) (PingResult, error)
    GetSystemInfo() (SystemInfo, error)
}

type commander struct{}

type PingResult struct {
    Successful bool          `json:"successful"`
    Time       time.Duration `json:"time"`
}

type SystemInfo struct {
    Hostname  string `json:"hostname"`
    IPAddress string `json:"ip_address"`
}

func NewCommander() Commander {
    return &commander{}
}

func (c *commander) Ping(host string) (PingResult, error) {
    start := time.Now()
    out, err := exec.Command("ping", "-n", "1", host).CombinedOutput()
    duration := time.Since(start)

    if err != nil {
        return PingResult{
            Successful: false,
            Time:       duration,
        }, fmt.Errorf("ping failed: %s", string(out))
    }

    if strings.Contains(string(out), "TTL=") {
        return PingResult{Successful: true, Time: duration}, nil
    }

    return PingResult{Successful: false, Time: duration}, fmt.Errorf("ping output: %s", string(out))
}


func (c *commander) GetSystemInfo() (SystemInfo, error) {
    hostname, err := os.Hostname()
    if err != nil {
        return SystemInfo{}, err
    }

    ip, err := getLocalIP()
    if err != nil {
        return SystemInfo{}, err
    }

    return SystemInfo{Hostname: hostname, IPAddress: ip}, nil
}

func getLocalIP() (string, error) {
    interfaces, err := net.Interfaces()
    if err != nil {
        return "", err
    }
    for _, i := range interfaces {
        if i.Flags&net.FlagUp == 0 || i.Flags&net.FlagLoopback != 0 {
            continue
        }
        addrs, err := i.Addrs()
        if err != nil {
            continue
        }
        for _, addr := range addrs {
            var ip net.IP
            switch v := addr.(type) {
            case *net.IPNet:
                ip = v.IP
            case *net.IPAddr:
                ip = v.IP
            }
            if ip == nil || ip.IsLoopback() {
                continue
            }
            ip = ip.To4()
            if ip == nil {
                continue
            }
            return ip.String(), nil
        }
    }
    return "", errors.New("no IP address found")
}
