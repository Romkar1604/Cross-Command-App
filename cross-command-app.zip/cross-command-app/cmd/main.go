package main

import (
    "log"
    "net/http"
    "github.com/Beryllium/cross-command-app/commander"
    "github.com/Beryllium/cross-command-app/server"
)

func main() {
    cmdr := commander.NewCommander()
    server := &http.Server{
        Addr:    ":8080",
        Handler: server.HandleRequests(cmdr),
    }
    log.Println("Server running on http://localhost:8080")
    log.Fatal(server.ListenAndServe())
}
